package com.work;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Step011Application {

	public static void main(String[] args) {
		SpringApplication.run(Step011Application.class, args);
	}

}
